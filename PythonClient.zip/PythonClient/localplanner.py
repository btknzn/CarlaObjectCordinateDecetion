#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 22:57:30 2022

@author: btknzn
"""

